package br.com.chckpoint_infinity_3sir

import br.com.chckpoint_infinity_3sir.model.Filme

class Database {

    companion object{
        val listaFilmes = mutableListOf<Filme>()
    }

}